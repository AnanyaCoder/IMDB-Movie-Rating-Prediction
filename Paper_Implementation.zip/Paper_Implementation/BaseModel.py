import numpy as np  
import re  
import nltk  
from sklearn.datasets import load_files  
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer 
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.model_selection import train_test_split  
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.naive_bayes import GaussianNB
from sklearn import svm
import pickle  
from nltk.corpus import stopwords 

#Downloading stop words
nltk.download('stopwords')  
 
#Loading data
movie_data = load_files("mix20_rand700_tokens_cleaned/tokens") 

#creating data and target 
X, y = movie_data.data, movie_data.target
#print(type(X))
#print(len(X))
#print(X[1001])
#print(y[1001])
#print(type(X))
documents = []

stemmer = WordNetLemmatizer()

for sen in range(0, len(X)):  
    # Remove all the special characters
    document = re.sub(r'\W', ' ', str(X[sen]))

    # remove all single characters
    document = re.sub(r'\s+[a-zA-Z]\s+', ' ', document)

    # Remove single characters from the start
    document = re.sub(r'\^[a-zA-Z]\s+', ' ', document) 

    # Substituting multiple spaces with single space
    document = re.sub(r'\s+', ' ', document, flags=re.I)

    # Removing prefixed 'b'
    document = re.sub(r'^b\s+', '', document)

    # Converting to Lowercase
    document = document.lower()

    # Lemmatization
    document = document.split()

    document = [stemmer.lemmatize(word) for word in document]
    document = ' '.join(document)

    documents.append(document)

 
#Converting text to numbers
vectorizer = CountVectorizer(max_features=1500, min_df=5, max_df=0.7, stop_words=stopwords.words('english'))  
X = vectorizer.fit_transform(documents).toarray()  


#calculating TFIDF
tfidfconverter = TfidfTransformer()  
X = tfidfconverter.fit_transform(X).toarray()  



#we can directly use TFIDF without using counter vectorizser which is of computing bag of words.
'''from sklearn.feature_extraction.text import TfidfVectorizer  
tfidfconverter = TfidfVectorizer(max_features=1500, min_df=5, max_df=0.7, stop_words=stopwords.words('english'))  
X = tfidfconverter.fit_transform(documents).toarray()  '''

#training  
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=0)
classifier1 = RandomForestClassifier(n_estimators=1000, random_state=0)  
classifier1 = svm.SVC(kernel='linear') # Linear Kernel
classifier1.fit(X_train, y_train)

#predicting
y_pred = classifier1.predict(X_test)

print("************classification report for all callsifiers used**********")
print("**************** svm ************************")

print(confusion_matrix(y_test,y_pred))  
print(classification_report(y_test,y_pred))  
print(accuracy_score(y_test, y_pred)) 



print("**************** naive_bayes ************************")
#Create a Gaussian Classifier
classifier2 = GaussianNB()

# Train the model using the training sets
classifier2.fit(X_train,y_train)

#Predict Output
y_pred= classifier2.predict(X_test) # 0:Overcast, 2:Mild
print(confusion_matrix(y_test,y_pred))  
print(classification_report(y_test,y_pred))  
print(accuracy_score(y_test, y_pred)) 


classifier3 = RandomForestClassifier(n_estimators=1000, random_state=0)  
classifier3.fit(X_train, y_train)

#predicting
y_pred = classifier3.predict(X_test)

print("**************** RandomForestClassifier ************************")

print(confusion_matrix(y_test,y_pred))  
print(classification_report(y_test,y_pred))  
print(accuracy_score(y_test, y_pred)) 

#saving our model as a pickle
'''with open('text_classifier_thumbsup', 'wb') as picklefile:  
    pickle.dump(classifier,picklefile)

#Loading the model
with open('text_classifier', 'rb') as training_model:  
    model = pickle.load(training_model)
y_pred2 = model.predict(X_test)

print(confusion_matrix(y_test, y_pred2))  
print(classification_report(y_test, y_pred2))  
print(accuracy_score(y_test, y_pred2))'''